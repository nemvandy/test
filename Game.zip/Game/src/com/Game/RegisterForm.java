package com.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterForm extends JFrame implements ActionListener {
    JLabel name;
    JTextField namefield;
    JButton addButton,save;
    JTextArea data;
    MainMenu mainMenu;
    RegisterForm(){
        super("Form");
        setSize(400,300);
        setLayout(new FlowLayout());
        setResizable(false);
        setLocationRelativeTo(null);
        add(name = new JLabel("Name"));
        add(namefield = new JTextField(10));
        add(addButton = new JButton("ADD"));
        add(save = new JButton("Save"));
        add(data = new JTextArea(20,20));

        setVisible(true);
        setDefaultCloseOperation
                (JFrame.EXIT_ON_CLOSE);
        addButton.addActionListener(this);
        save.addActionListener(this);
    }

    public static void main(String[] args) {
        new RegisterForm();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource()==addButton ){
            data.append(namefield.getText());
          //  MainMenu menu = new MainMenu();
           JOptionPane.showMessageDialog(null,"New Player");
           new MainMenu();
        }
        if(e.getSource()==save){
         //   MainMenu menu = new MainMenu();
        }

    }
}
