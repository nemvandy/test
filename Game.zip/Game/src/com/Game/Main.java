package com.Game;

public class Main {

    public static void main(String[] args) {
       // RegisterForm registerForm = new RegisterForm();

         MainMenu mainMenu = new MainMenu();
//        Maze maze = new Maze();
//        MapMakerTile mapMakerTile = new MapMakerTile();
//       // Maze maze = new Maze();
//       // MazeMapMaker mazeMapMaker = new MazeMapMaker();
//        Player player = new Player();
//        Tile tile = new Tile();


    }

}
